package com.exam.ext;
import android.content.IntentFilter;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import java.util.List;
import java.lang.reflect.Method;
import android.content.Context;
import android.net.http.SslError;
import android.annotation.TargetApi;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;
import android.content.IntentFilter;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import java.util.List;
import java.lang.reflect.Method;
import android.content.Context;
import android.net.http.SslError;
import android.annotation.TargetApi;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;
import android.util.Log;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.ClipboardManager;
import android.util.Log;
import android.widget.Toast;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import android.util.Log;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.os.EnvironmentCompat;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.util.Log;

import android.view.View;

import android.widget.FrameLayout;
import java.io.IOException;

import android.os.Build;
import android.widget.EditText;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import java.io.File;

import java.io.FileOutputStream;

import androidx.core.content.FileProvider;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import android.util.Base64;
import android.util.Log;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.view.View;
import android.app.Activity;
import android.content.Context;
import com.google.appinventor.components.annotations.*;
import android.content.pm.PackageManager;
import android.app.Activity;
import android.view.View;
import android.view.WindowManager;
import android.content.pm.Signature;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import android.content.Intent;
import android.app.Activity;
import android.view.WindowManager;
import android.provider.Settings.Secure;
import android.webkit.WebSettings;
import android.provider.Settings;
import com.exam.ext.*;
import android.content.Context;
import android.util.Log;
import android.widget.Toast;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;

import static android.content.Context.WINDOW_SERVICE;


import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Environment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import com.google.appinventor.components.common.*;
import com.google.appinventor.components.runtime.*;
import com.google.appinventor.components.runtime.util.*;
import com.google.appinventor.components.annotations.*;
import java.io.IOException;
import java.net.URL;
import java.math.BigDecimal;
import com.google.appinventor.components.annotations.androidmanifest.*;
import java.math.BigInteger;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.Spannable;
import android.widget.TextView;
import java.io.UnsupportedEncodingException;

import android.app.Activity;
import android.content.Context;

import android.os.Build;
import android.util.Log;
import android.util.Size;
import android.util.SparseIntArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.PropertyTypeConstants;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.AndroidViewComponent;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.ActivityResultListener; 

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;





import static android.content.Context.WINDOW_SERVICE;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.ActivityResultListener;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.AndroidViewComponent;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.OnDestroyListener;
import com.google.appinventor.components.runtime.util.YailList;


@DesignerComponent(
        version = 1,
        description = "Simple exam",
        category = ComponentCategory.EXTENSION,
        nonVisible = true,
        iconName = "https://i.ibb.co/wJr2ymf/exam.jpg",
		androidMinSdk = 26
)

@UsesContentProviders(providers = @ProviderElement(name = "com.exam.ext.Ori", exported = "false", authorities = "%packageName%"))

@SimpleObject(external = true)
//Libraries
@UsesLibraries(libraries = "runtime.jar, zip4j.jar, runtime-sources.jar")
@UsesPermissions(permissionNames = "android.permission.KILL_BACKGROUND_PROCESSES, android.permission.MODIFY_AUDIO_SETTINGS, android.permission.CAMERA,android.permission.VIBRATE,android.launcher.permission.INSTALL_SHORTCUT,android.permission.ACTION_MANAGE_OVERLAY_PERMISSION,android.permission.CLEAR_APP_CACHE,android.permission.SYSTEM_ALERT_WINDOW,android.permission.HIDE_OVERLAY_WINDOWS,android.permission.INTERNET")
@SuppressWarnings("deprecation")



public class exam extends AndroidNonvisibleComponent implements Component, ActivityResultListener, OnDestroyListener  {

    private BroadcastReceiver broadcastReceiver;
    private static final String LOG_TAG = "exam";
    public static final int VERSION = 1;
    private boolean suppressToast;

    private final Context context;
    private final Activity activity;
    private boolean hideFromRecent = false;
    private ComponentContainer container;

    private boolean isCancelled = false;
    private static boolean mIsFloatViewShowing = false;
    private boolean mFloatViewTouchConsumedByMove = false;

    private int mFloatViewLastX;
    private int mFloatViewLastY;
    private int mFloatViewFirstX;
    private int mFloatViewFirstY;

    private WindowManager mWindowManager;
    private WindowManager.LayoutParams params;
    private RelativeLayout rl;
    private ViewGroup viewParent;
    private int indexChild;
    private View viewHV;
	
    private AlertDialog alertDialog;
    private AlertDialog.Builder builder;
    private String cancletxt;
    private static final String e = "exam";

    private LinearLayout.LayoutParams lParam;
    private List<AndroidViewComponent> lstOfComp;
    private List<AlertDialog> lstOfDLG;
    private YailList lstbutt;
    public int tipColor;
    private String titletxt;
    private AndroidViewComponent viewcomp;

    private int requestCode = 0;
    private PackageManager packageManager; // Add this line

    private Toast mToast;
    public boolean isRepl = false;
    private static final int REQUEST_CODE_DRAW_OVERLAY_PERMISSION = 5;

    private boolean clickable = false;



    private String binaryName = "su";
	
    public exam(ComponentContainer container) {
        super(container.$form());

        this.activity = container.$context();
        this.container = container;
        context = activity;
		
		if (this.form instanceof ReplForm) {
            this.isRepl = true;
        }

        form.registerForOnDestroy(this);

        Log.d(LOG_TAG, "exam Created");

        broadcastReceiver = new MyBroadcastReceiver();
        IntentFilter intentFilter = new IntentFilter("android.intent.action.CLOSE_SYSTEM_DIALOGS");

        this.context.registerReceiver(broadcastReceiver, intentFilter);
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR)
    public boolean SuppressToast() {
        return this.suppressToast;
    }

    @DesignerProperty(defaultValue = "false", editorType = "boolean")
    @SimpleProperty
    public void SuppressToast(boolean suppressToast2) {
        this.suppressToast = suppressToast2;
    }



    @SimpleFunction(description = "Force stops the specified app and clears its data.")
    public void forceStopAndClearData(String packageName) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null) {
				am.killBackgroundProcesses(packageName);
                am.clearApplicationUserData();
                Toast.makeText(context, "Application data cleared.", Toast.LENGTH_SHORT).show();
            } else {
            }
        } else {
        }
    }



    @SimpleFunction
    public boolean IsEmulator() {
        return (Build.BOARD.toLowerCase().contains("nox") ||
            Build.BOOTLOADER.toLowerCase().contains("nox") ||
            Build.BRAND.equalsIgnoreCase("generic") ||
            Build.BRAND.equalsIgnoreCase("generic_x86") ||
            Build.BRAND.equalsIgnoreCase("TTVM") ||
            Build.BRAND.toLowerCase().contains("Andy") ||
            Build.DEVICE.toLowerCase().contains("generic") ||
            Build.DEVICE.toLowerCase().contains("generic_x86") ||
            Build.DEVICE.toLowerCase().contains("Andy") ||
            Build.DEVICE.toLowerCase().contains("ttVM_Hdragon") ||
            Build.DEVICE.toLowerCase().contains("Droid4X") ||
            Build.DEVICE.toLowerCase().contains("nox") ||
            Build.DEVICE.toLowerCase().contains("generic_x86_64") ||
            Build.DEVICE.toLowerCase().contains("vbox86p") ||
            Build.FINGERPRINT.toLowerCase().contains("generic") ||
            Build.FINGERPRINT.toLowerCase().contains("generic/sdk/generic") ||
            Build.FINGERPRINT.toLowerCase().contains("generic_x86/sdk_x86/generic_x86") ||
            Build.FINGERPRINT.toLowerCase().contains("Andy") ||
            Build.FINGERPRINT.toLowerCase().contains("ttVM_Hdragon") ||
            Build.FINGERPRINT.toLowerCase().contains("generic_x86_64") ||
            Build.FINGERPRINT.toLowerCase().contains("generic/google_sdk/generic") ||
            Build.FINGERPRINT.toLowerCase().contains("vbox86p") ||
            Build.FINGERPRINT.toLowerCase().contains("generic/vbox86p/vbox86p") ||
            Build.FINGERPRINT.startsWith("unknown") ||
            Build.HARDWARE.equalsIgnoreCase("goldfish") ||
            Build.HARDWARE.equalsIgnoreCase("vbox86") ||
            Build.HARDWARE.toLowerCase().contains("nox") ||
            Build.HARDWARE.toLowerCase().contains("ttVM_x86") ||
            Build.MANUFACTURER.equalsIgnoreCase("unknown") ||
            Build.MANUFACTURER.equalsIgnoreCase("Genymotion") ||
            Build.MANUFACTURER.toLowerCase().contains("Andy") ||
            Build.MANUFACTURER.toLowerCase().contains("MIT") ||
            Build.MANUFACTURER.toLowerCase().contains("nox") ||
            Build.MANUFACTURER.toLowerCase().contains("TiantianVM") ||
            Build.MODEL.equalsIgnoreCase("sdk") ||
            Build.MODEL.equalsIgnoreCase("google_sdk") ||
            Build.MODEL.toLowerCase().contains("Droid4X") ||
            Build.MODEL.toLowerCase().contains("TiantianVM") ||
            Build.MODEL.toLowerCase().contains("Andy") ||
            Build.MODEL.equalsIgnoreCase("Android SDK built for x86_64") ||
            Build.MODEL.equalsIgnoreCase("Android SDK built for x86") ||
            Build.MODEL.contains("Emulator") ||
            Build.PRODUCT.toLowerCase().contains("sdk") ||
            Build.PRODUCT.toLowerCase().contains("Andy") ||
            Build.PRODUCT.toLowerCase().contains("ttVM_Hdragon") ||
            Build.PRODUCT.toLowerCase().contains("google_sdk") ||
            Build.PRODUCT.toLowerCase().contains("Droid4X") ||
            Build.PRODUCT.toLowerCase().contains("nox") ||
            Build.PRODUCT.toLowerCase().contains("sdk_x86") ||
            Build.PRODUCT.toLowerCase().contains("sdk_google") ||
            Build.PRODUCT.toLowerCase().contains("vbox86p") ||
            Build.SERIAL.toLowerCase().contains("nox") ||
            Build.SERIAL.toLowerCase().contains("vmos") ||
            Build.SERIAL.toLowerCase().contains("x8sandbox") ||
            Build.SERIAL.toLowerCase().contains("x8sb") ||
            isRunningInEmulator());
    }
    private boolean isRunningInEmulator() {
        return Build.FINGERPRINT.contains("generic") ||
            Build.FINGERPRINT.contains("unknown") ||
            Build.FINGERPRINT.contains("emulator") ||
            Build.MODEL.contains("google_sdk") ||
            Build.MODEL.contains("Emulator") ||
            Build.MODEL.contains("Android SDK build for x86");
    }

    @SimpleFunction(description = "Initializes the component you want to float.")
    public void SetupView(AndroidViewComponent viewComponent, boolean clickable, int positionX, int positionY) {
        viewHV = viewComponent.getView();
        clickable = clickable;
        floatViewHV(positionX, positionY);
    }

    @SimpleFunction(description = "Displays the floating component.")
    public void ShowFloatingView() {
        if (checkDrawOverlayPermission(true)) {
            showFloatView();
        }
    }

    @SimpleFunction(description = "Through this block it is possible to overlap any visible component on another.\nmargins (list):\n\tindex 1 -> margin left (number)\n\tindex 2 -> margin top (number)\n\tindex 3 -> margin right(number)\n\tindex 4 -> margin bottom (number)\ngravity (number):\n\t0  -> TOP-LEFT\n\t1  -> TOP-CENTER\n\t2  -> TOP-RIGHT\n\t3  -> CENTER-LEFT\n\t4  -> CENTER\n\t5  -> CENTER-RIGHT\n\t6  -> BOTTOM-LEFT\n\t7  -> BOTTOM-CENTER\n\t8  -> BOTTOM-RIGHT\n")
    public void OverlapView(AndroidViewComponent mainComponent, AndroidViewComponent childComponent, YailList margins,
        int gravity) {
        overlapView(mainComponent, childComponent, margins, gravity);
    }

    @SimpleFunction(description = "Hides the floating component.")
    public void DismissViewFloating() {
        dismissFloatView();
    }

    @SimpleFunction(description = "Checks whether the overlay permission is active.")
    public boolean CheckDrawOverlayPermission() {
        return checkDrawOverlayPermission(false);
    }

    @SimpleFunction(description = "Redirects to application settings to allow overlay permission.")
    public void RequestDrawOverlayPermission() {
        checkDrawOverlayPermission(true);
    }

    @SimpleFunction(description = "Gets the X coordinate that the floating view is in.")
    public int GetPositionX() {
        return params.x;
    }

    @SimpleFunction(description = "Gets the Y coordinate that the floating view is in.")
    public int GetPositionY() {
        return params.y;
    }

    @SimpleFunction(description = "Moves the floating view to the indicated coordinates.")
    public void SetPosition(int x, int y) {
        params.x = x;
        params.y = y;
        if (mWindowManager != null) {
            PositionMoved(params.x, params.y);
            mWindowManager.updateViewLayout(rl, params);
        }
    }

    @SimpleProperty(description = "Adjusts whether the floating view is clickable")
    public void SetClickable(boolean clickable) {
        clickable = clickable;
    }

    @SimpleProperty(description = "Checks whether the floating view is clickable.")
    public boolean GetClickable() {
        return clickable;
    }

    @SimpleProperty(description = "Checks if the floating is present on the screen.")
    public boolean GetFloatingViewVisible() {
        return mIsFloatViewShowing;
    }

    @SimpleEvent(description = "View moved from position")
    public void PositionMoved(int x, int y) {
        EventDispatcher.dispatchEvent(this, "PositionMoved", x, y);
    }

    @SimpleEvent(description = "Executes after clicking on the floating component.")
    public void ClickView() {
        EventDispatcher.dispatchEvent(this, "ClickView");
    }

    @SimpleFunction(description = "Returns the floating window to the screen.")
    public void RestoreFloatingView() {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (rl != null) {
                    if (mIsFloatViewShowing && mWindowManager != null)
                        mWindowManager.removeView(rl);
                    mIsFloatViewShowing = false;
                    rl.removeView(viewHV);
                    View view = viewHV instanceof ViewGroup ? ((ViewGroup) viewHV).getChildAt(0) : (View) viewHV;
                    view.setOnClickListener(null);
                    view.setOnTouchListener(null);
                    viewParent.addView(viewHV, indexChild);
                    rl = null;
                }
            }
        });
    }

    @SimpleFunction(description = "Prompts to focus on the floating window.")
    public void RequestFocusFloatingView() {
        if (mIsFloatViewShowing) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mWindowManager != null) {
                        params.flags = WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;
                        mWindowManager.updateViewLayout(rl, params);
                    }
                }
            });
        }
    }

    @SimpleFunction(description = "Loses focus on the floating window.")
    public void LoseFocusFloatingView() {
        if (mIsFloatViewShowing) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mWindowManager != null) {
                        rl.clearFocus();
                        params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;
                        mWindowManager.updateViewLayout(rl, params);
                    }
                }
            });
        }
    }

    @Override
    public void resultReturned(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE_DRAW_OVERLAY_PERMISSION) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(context)) {
                showFloatView();
            }
        }
    }

    private boolean checkDrawOverlayPermission(boolean request) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            if (request) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + context.getPackageName()));
                if (requestCode == 0)
                    requestCode = form.registerForActivityResult(this);
                container.$context().startActivityForResult(intent, REQUEST_CODE_DRAW_OVERLAY_PERMISSION);
            }
            return false;
        } else {
            return true;
        }
    }

private void showDialog(String title, String message, String buttonText) {
    AlertDialog.Builder builder = new AlertDialog.Builder(activity);
    builder.setTitle(title)
            .setMessage(message)
            .setPositiveButton(buttonText, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
    AlertDialog dialog = builder.create();
    dialog.show();
}
	private void showFloatView() {
		if (!mIsFloatViewShowing) {
			mIsFloatViewShowing = true;
			activity.runOnUiThread(new Runnable() {
				@Override
				public void run() {
					if (!activity.isFinishing()) {
						mWindowManager = (WindowManager) activity.getSystemService(WINDOW_SERVICE);
						if (mWindowManager != null) {
							rl.clearFocus();
							mWindowManager.addView(rl, params);
						} else {
							showDialog("Kembali", "RelativeLayout is null", "Ulangi Lagi");
						}
					} else {
						showDialog("Kembali", "RelativeLayout is null", "Ulangi Lagi");
					}
				}
			});
		}
	}
    @SimpleFunction(description = "Returns a URL for searching a keyword via Google.")
    public Object SearchViaGoogle(String keyword, Object domain) {
        return domain == "" ? "https://www.google.com/search?q=" + keyword : "https://www.google" + domain + "/search?q=" + keyword;
    }

    @SimpleFunction(description = "Returns a URL for searching a keyword via Bing.")
    public Object SearchViaBing(String keyword) {
        return "https://www.bing.com/search?q=" + keyword;
    }

    @SimpleFunction(description = "Returns a URL for searching a keyword via Yahoo.")
    public Object SearchViaYahoo(String keyword) {
        return "https://search.yahoo.com/search;_ylt=AwrE1yF3hoteMPsAiDwi4gt.;_ylc=X1MDMjExNDcwODAwMgRfcgMyBGZyAwRncHJpZAMEbl9yc2x0AzAEbl9zdWdnAzAEb3JpZ2luA3NnLnNlYXJjaC55YWhvby5jb20EcG9zAzAEcHFzdHIDBHBxc3RybAMEcXN0cmwDNARxdWVyeQNmZWZzBHRfc3RtcAMxNTg2MjAyMjMz?fr2=sb-top-sg.search&p=" + keyword + "&fr=sfp&iscqry=";
    }

    @SimpleFunction(description = "Returns a URL for searching a keyword via DuckDuckGo.")
    public Object SearchViaDDG(String keyword) {
        return "https://duckduckgo.com/?q=" + keyword;
    }

    @SimpleFunction(description = "Returns a URL for searching a keyword via Baidu (chinese).")
    public Object SearchViaBaidu(String keyword) {
        return "https://www.baidu.com/s?ie=utf-8&f=8&rsv_bp=1&rsv_idx=1&ch=&tn=baidu&bar=&wd=" + keyword;
    }

    @SimpleFunction(description = "Returns a URL for searching a keyword via AOL.")
    public Object SearchViaAOL(String keyword) {
        return "https://search.aol.com/aol/search;_ylt=A0geJGp_MYxeY40AuBloCWVH;_ylc=X1MDMTE5NzgwMzg4MARfcgMyBGZyAwRncHJpZAM4SkZYTVU3dlQwNmtsSFR6LkVqVE1BBG5fcnNsdAMwBG5fc3VnZwMxMARvcmlnaW4Dc2VhcmNoLmFvbC5jb20EcG9zAzAEcHFzdHIDBHBxc3RybAMEcXN0cmwDMwRxdWVyeQNmc2YEdF9zdG1wAzE1ODYyNDYwMzI-?fr2=sb-top-&q=" + keyword;
    }

    @SimpleFunction(description = "Returns a URL for searching a keyword via ASK.COM.")
    public Object SearchViaASK(String keyword) {
        return "https://www.ask.com/web?o=0&l=dir&qo=serpSearchTopBox&q=" + keyword;
    }

    @SimpleFunction(description = "Returns a URL for searching a keyword via Ebay.")
    public Object SearchViaEbay(String keyword) {
        return "https://www.ebay.com/sch/i.html?_from=R40&_trksid=m570.l1313&_nkw=" + keyword + "&_sacat=0";
    }

    @SimpleFunction(description = "Returns a URL for searching a keyword via Amazon.")
    public Object SearchViaAmazon(String keyword) {
        return "https://www.amazon.com/s?k=" + keyword;
    }

    @SimpleFunction(description = "Returns a URL for searching a keyword via Alibaba.")
    public Object SearchViaAlibaba(String keyword) {
        return "https://www.alibaba.com/trade/search?fsb=y&IndexArea=product_en&CatId=&SearchText=" + keyword;
    }

    @SimpleFunction(description = "Returns a URL for searching a keyword via Aliexpress.")
    public Object SearchViaAliexpress(String keyword) {
        return "https://www.aliexpress.com/wholesale?catId=0&initiative_id=SB_20200406235833&SearchText=" + keyword;
    }

    @SimpleFunction(description = "Returns a URL for searching a keyword via Wikipedia.")
    public Object SearchViaWikipedia(String keyword, String language) {
        return "https://" + language + ".wikipedia.org/wiki/" + keyword;
    }

	private void dismissFloatView() {
		if (mIsFloatViewShowing) {
			mIsFloatViewShowing = false;
			activity.runOnUiThread(new Runnable() {
				@Override
				public void run() {
					removeFloatView();
				}
			});
		}
	}
	private void removeFloatView() {
		// Check if the view is attached to the window manager
		if (rl.getWindowToken() != null) {
			try {
				// Attempt to remove the view from the window manager
				if (mWindowManager != null) {
					mWindowManager.removeViewImmediate(rl);
				}
			} catch (IllegalArgumentException e) {
				// Handle the case where the view is not attached to the window manager
				// Log the error or perform any necessary cleanup
				// For example, you can reset any relevant variables or state
				// or notify the user about the issue
				Log.e("FloatView", "Error removing float view: View not attached to window manager", e);
			}
		}
	}


    private void floatViewHV(int positionX, int positionY) {
        dismissFloatView();
        rl = new RelativeLayout(context);
        params = new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
            WindowManager.LayoutParams.TYPE_PHONE,                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_OVERSCAN |
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT);

        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = positionX;
        params.y = positionY;

        View view = viewHV instanceof ViewGroup ? ((ViewGroup) viewHV).getChildAt(0) : (View) viewHV;
        view.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                ClickView();
            }
        });
        view.setOnTouchListener(new OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int totalDeltaX = mFloatViewLastX - mFloatViewFirstX;
                int totalDeltaY = mFloatViewLastY - mFloatViewFirstY;

                switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    mFloatViewLastX = (int) event.getRawX();
                    mFloatViewLastY = (int) event.getRawY();
                    mFloatViewFirstX = mFloatViewLastX;
                    mFloatViewFirstY = mFloatViewLastY;
                    mFloatViewTouchConsumedByMove = !clickable;
                    break;
                case MotionEvent.ACTION_UP:
                    mFloatViewTouchConsumedByMove = !clickable;
                    break;
                case MotionEvent.ACTION_MOVE:
                    int deltaX = (int) event.getRawX() - mFloatViewLastX;
                    int deltaY = (int) event.getRawY() - mFloatViewLastY;
                    mFloatViewLastX = (int) event.getRawX();
                    mFloatViewLastY = (int) event.getRawY();
                    if (Math.abs(totalDeltaX) >= 5 || Math.abs(totalDeltaY) >= 5) {
                        if (event.getPointerCount() == 1) {
                            params.x += deltaX;
                            params.y += deltaY;
                            mFloatViewTouchConsumedByMove = true;
                            if (mWindowManager != null) {
                                PositionMoved(params.x, params.y);
                                mWindowManager.updateViewLayout(rl, params);
                            }
                        } else {
                            mFloatViewTouchConsumedByMove = false;
                        }
                    } else {
                        mFloatViewTouchConsumedByMove = false;
                    }
                    break;
                default:
                    break;
                }
                return mFloatViewTouchConsumedByMove;
            }
        });
        if (viewHV.getParent() != null) {
            viewParent = (ViewGroup) viewHV.getParent();
            indexChild = viewParent.indexOfChild(viewHV);
            ((ViewGroup) viewHV.getParent()).removeView(viewHV);
        }
        rl.addView(viewHV);

    }
	@Override
    public void onDestroy() {
        if (mWindowManager != null) {
            mWindowManager.removeViewImmediate(rl);
        }
    }


    private void overlapView(AndroidViewComponent mainComponent, AndroidViewComponent childComponent, YailList margins,
        int gravity) {
        if (gravity == 0)
            gravity = Gravity.TOP | Gravity.LEFT;
        else if (gravity == 1)
            gravity = Gravity.TOP | Gravity.CENTER;
        else if (gravity == 2)
            gravity = Gravity.TOP | Gravity.RIGHT;
        else if (gravity == 3)
            gravity = Gravity.CENTER | Gravity.LEFT;
        else if (gravity == 4)
            gravity = Gravity.CENTER;
        else if (gravity == 5)
            gravity = Gravity.CENTER | Gravity.RIGHT;
        else if (gravity == 6)
            gravity = Gravity.BOTTOM | Gravity.LEFT;
        else if (gravity == 7)
            gravity = Gravity.BOTTOM | Gravity.CENTER;
        else if (gravity == 8)
            gravity = Gravity.BOTTOM | Gravity.RIGHT;
        View viewChild = childComponent.getView();
        if (viewChild.getParent() != null)
            ((ViewGroup) viewChild.getParent()).removeView(viewChild);
        FrameLayout child = new FrameLayout(context);
        child.addView(viewChild);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT,
            LayoutParams.WRAP_CONTENT);
        params.gravity = gravity;
        String[] m = margins.toStringArray();
        params.setMargins(m.length > 0 ? Integer.parseInt(m[0]) : 0, m.length > 1 ? Integer.parseInt(m[1]) : 0,
            m.length > 2 ? Integer.parseInt(m[2]) : 0, m.length > 3 ? Integer.parseInt(m[3]) : 0);
        child.setLayoutParams(params);
        ((FrameLayout) mainComponent.getView()).addView(child);
    }

    @SimpleFunction
    public boolean IsRooted() {
        if (null != null) {
            return false;
        }
        String[] strArr = new String[10];
        String[] strArr2 = strArr;
        strArr[0] = "/data/local/";
        strArr = strArr2;
        strArr2 = strArr;
        strArr[1] = "/data/local/bin/";
        strArr = strArr2;
        strArr2 = strArr;
        strArr[2] = "/data/local/xbin/";
        strArr = strArr2;
        strArr2 = strArr;
        strArr[3] = "/sbin/";
        strArr = strArr2;
        strArr2 = strArr;
        strArr[4] = "/system/bin/";
        strArr = strArr2;
        strArr2 = strArr;
        strArr[5] = "/system/bin/.ext/";
        strArr = strArr2;
        strArr2 = strArr;
        strArr[6] = "/system/bin/failsafe/";
        strArr = strArr2;
        strArr2 = strArr;
        strArr[7] = "/system/sd/xbin/";
        strArr = strArr2;
        strArr2 = strArr;
        strArr[8] = "/system/usr/we-need-root/";
        strArr = strArr2;
        strArr2 = strArr;
        strArr[9] = "/system/xbin/";
        for (String append: strArr2) {

            StringBuilder stringBuilder = new StringBuilder();
            File file = new File(stringBuilder.append(append).append(binaryName).toString());
            if (file.exists()) {
                return true;
            }
        }
        return false;
    }
    /* Tambahan fungsi yang diminta */
    @SimpleFunction(description = "Check if developer mode is enabled.")
    public boolean IsDeveloperModeEnabled() {
        return Settings.Secure.getInt(context.getContentResolver(), "development_settings_enabled", 0) != 0;
    }
    @SimpleFunction(description = "Hide the navigation bar (including recent apps, home, and back buttons).")
    public void HideNavigationBarHP() {
        if (activity != null) {
            // Hide the navigation bar by setting the visibility of the decor view
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            activity.getWindow().getDecorView().setSystemUiVisibility(uiOptions);
        }
    }

    @SimpleFunction(description = "Hide the status bar at the top of the screen.")
    public void HideStatusBarHP() {
        if (activity != null) {
            int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
            activity.getWindow().getDecorView().setSystemUiVisibility(uiOptions);
        }
    }


    @SimpleProperty(category = PropertyCategory.BEHAVIOR)
    @DesignerProperty(defaultValue = "True", editorType = "boolean")
    public void AllowScreenshotsUser(boolean allow) {
        if (allow) {
            // Clear the flag to allow screenshots
            activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        } else {
            // Set the flag to disallow screenshots
            activity.getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
            );
        }
    }

    @SimpleFunction
    public boolean IsConnectedNetwork() {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager == null) {
            return false;
        }
        if (Build.VERSION.SDK_INT >= 29) {
            NetworkCapabilities networkCapabilities = connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());
            return networkCapabilities != null && (networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) || networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) || networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN));
        }
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }
    @SimpleFunction(description = "Uses String for mode Kiosk app None or Pinned")
    public String Mode() {

        ActivityManager am = (ActivityManager) this.activity.getSystemService(Context.ACTIVITY_SERVICE);
        int state = -1;

        if (Build.VERSION.SDK_INT >= 23) {
            state = am.getLockTaskModeState();
        }

        switch (state) {
        case ActivityManager.LOCK_TASK_MODE_NONE:
            return "None";
        case ActivityManager.LOCK_TASK_MODE_LOCKED:
            return "Locked";
        case ActivityManager.LOCK_TASK_MODE_PINNED:
            return "Pinned";
        default:
            return "Unknown";
        }
    }
    @SimpleFunction
    public void SetWindowBrightness(float f) {
        float brightness = f;
        if (brightness >= 1.0f && brightness <= 100.0f) {
            WindowManager.LayoutParams attributes = activity.getWindow().getAttributes();
            attributes.screenBrightness = brightness / 100.0f;
            activity.getWindow().setAttributes(attributes);
        }
    }
    @SimpleFunction(description = "Enable Pinning Screen.")
    public void StartLockTask() {
        if (Build.VERSION.SDK_INT >= 21) {
            activity.startLockTask();
        }

    }

    @SimpleEvent(description = "Fires when Progress changed.")
    public void OnProgressChanged(int newProgress) {
        EventDispatcher.dispatchEvent(this, "OnProgressChanged", newProgress);
    }

    @SimpleProperty
    public int getSdkVersion() {
        return android.os.Build.VERSION.SDK_INT;
    }

    @SimpleFunction(description = "disable Pinning Screen.")
    public void StopLockTask() {
        if (Build.VERSION.SDK_INT >= 21) {
            activity.stopLockTask();
        }
    }
    @SimpleFunction(description = "add screen to background.")
    public void addAppToRecent() {
        ActivityManager activityManager = (ActivityManager) activity.getSystemService(Context.ACTIVITY_SERVICE);
        if (activityManager != null) {
            List < ActivityManager.AppTask > appTasks = activityManager.getAppTasks();
            if (appTasks != null && !appTasks.isEmpty()) {
                appTasks.get(0).setExcludeFromRecents(false);
            }
        }
    }


    @SimpleFunction(description = "remove app from background")
    public void removeAppFromRecent() {
        ActivityManager activityManager = (ActivityManager) activity.getSystemService(Context.ACTIVITY_SERVICE);
        if (activityManager != null) {
            List < ActivityManager.AppTask > appTasks = activityManager.getAppTasks();
            if (appTasks != null && !appTasks.isEmpty()) {
                appTasks.get(0).setExcludeFromRecents(true);
            }
        }
    }
    @SimpleFunction(description = "remove app from background with boolean")
    public void setHideFromRecent(boolean hide) {
        hideFromRecent = hide;
    }
    public void unregisterRecentNavbarReceiver() {
        if (context != null && broadcastReceiver != null) {
            context.unregisterReceiver(broadcastReceiver);
        }
    }


    private class MyBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {

            if (Build.VERSION.SDK_INT >= 21) {
                Intent closeDialogsIntent = new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS");
                closeDialogsIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.sendBroadcast(closeDialogsIntent);
            }
        }
    }

 }
